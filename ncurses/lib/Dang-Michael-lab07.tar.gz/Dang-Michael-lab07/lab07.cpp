/*
Write a C++ program that displays the contents of a file in curses mode.
If the contents of the file are too big to fit on the screen,
then your program needs to allow the user to scroll through the output
using the up and down arrow keys.
*/

#include <ncurses.h>

int main(const int argc, const char * argv []);


